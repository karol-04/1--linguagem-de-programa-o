nivelDificuldade = Number(window.prompt("Qual a dificuldade do gosto você gostaria de jogar? Responda de 1 a 15."));
var largura = 600; 
var altura = 400; 
var corTabuleiro = "#1F8340";
var corBolinha = 0; 
var xBolinha = 300;
var yBolinha = 200; 
var dBolinha = 20; 
var velocidadeXBolinha = nivelDificuldade;
var velocidadeYBolinha = nivelDificuldade; 
var xRaquete1 = 20; 
var yRaquete1 = 150;
var lRaquete1 = 10; 
var aRaquete1 = 100; 
var vRaquete1 = nivelDificuldade * 2; 
var pontos1 = 0;
var xRaquete2 = 570; 
var yRaquete2 = 150; 
var lRaquete2 = 10; 
var aRaquete2 = 100; 
var vRaquete2 = nivelDificuldade * 2; 
var pontos2 = 0;

function setup() {
  createCanvas(largura, altura);
} 

function criarTabuleiro(corTabuleiro){
  background(corTabuleiro);
} 
function criarBolinha(xBolinha, yBolinha, dBolinha, corBolinha){
  circle(xBolinha, yBolinha, dBolinha);
  fill(corBolinha);
} 
function movimentarBolinha(){
  xBolinha = xBolinha + velocidadeXBolinha;
  yBolinha = yBolinha + velocidadeYBolinha;
} 
function verificarColisao(){
  if (xBolinha >= (largura - (dBolinha/2)) || xBolinha < (dBolinha/2)){
    velocidadeXBolinha = -1 * velocidadeXBolinha
  }
  if (yBolinha >= (altura - (dBolinha/2)) || yBolinha < (dBolinha/2)){
    velocidadeYBolinha = -1 * velocidadeYBolinha
  }
  if (xBolinha == (largura - (dBolinha/2)) || xBolinha <= 0 + (dBolinha/2)){
    xBolinha = largura / 2;
    yBolinha = altura / 2;
  }
} 
function criarRaquete1(xRaquete1, yRaquete1, lRaquete1, aRaquete1, corRaquete){
  rect(xRaquete1, yRaquete1, lRaquete1, aRaquete1);
}


function criarRaquete2(xRaquete2, yRaquete2, lRaquete2, aRaquete2, corRaquete){
rect(xRaquete2, yRaquete2, lRaquete2, aRaquete2);
}

function movimentarRaquete1(){
  if (keyIsDown(87)){ 
    if(yRaquete1 >= 0){
      yRaquete1 = yRaquete1 - vRaquete1; } 
  } 
  if (keyIsDown(83)){ 
    if (yRaquete1 <= (altura - aRaquete1)){
      yRaquete1 = yRaquete1 + vRaquete1; } 
  }
}

function movimentarRaquete2(){
  if (keyIsDown(UP_ARROW)){
    if(yRaquete2 >= 0){
      yRaquete2 = yRaquete2 - vRaquete2; } 
  } 
  if (keyIsDown(DOWN_ARROW)){ 
    if (yRaquete2 <= (altura - aRaquete2)){
      yRaquete2 = yRaquete2 + vRaquete2; } 
  }
}

 function verificarColisaoRaquete1(){ 
   if(xBolinha - (dBolinha/2) <= xRaquete1 + lRaquete1 && yBolinha - (dBolinha/2) <= yRaquete1 + aRaquete1 && yBolinha + (dBolinha/2) >= yRaquete1){
   velocidadeXBolinha = velocidadeXBolinha * -1 
   velocidadeYBolinha = velocidadeYBolinha * -1
     pontos1=pontos1+1
   }
 }
 function verificarColisaoRaquete2(){ 
   if (xBolinha + (dBolinha/2) >= xRaquete2 - lRaquete2 && yBolinha - (dBolinha/2) <= yRaquete2 + aRaquete2 && yBolinha + (dBolinha/2) >= yRaquete2){ 
     velocidadeXBolinha = velocidadeXBolinha * -1 
     velocidadeYBolinha = -1 * velocidadeYBolinha 
     pontos2 = pontos2 + 1 } }
function placar(){
textSize(22);
text("Player 1: "+ pontos1, (largura/2)-110, 22);
textSize(22);
text("Player 2: "+ pontos2, (largura/2)-110, 44);
fill(0, 102, 153)
  
}

function draw() {
  criarTabuleiro(corTabuleiro);
  criarBolinha(xBolinha, yBolinha, dBolinha, corBolinha);
  movimentarBolinha();
  verificarColisao();  
  criarRaquete1(xRaquete1, yRaquete1, lRaquete1, aRaquete1);
  criarRaquete2(xRaquete2, yRaquete2, lRaquete2, aRaquete2);
  movimentarRaquete1();
  movimentarRaquete2();
  verificarColisaoRaquete1();
  verificarColisaoRaquete2();
  placar();
}